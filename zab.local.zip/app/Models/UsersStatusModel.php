<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsersStatusModel extends Model
{
    protected $table = "users_statuses";

    public $timestamps = "false";
}
