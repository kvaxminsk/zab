<?php $__env->startSection('content'); ?>
    <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-6 col-md-3 sidebar-offcanvas" id="sidebar" style="margin-top:20px">
            <div class="list-group">
                <a href="<?php echo e(route('category',['category_id' => 0])); ?>" class="list-group-item <?php echo e(($category_id) ? '' : 'active'); ?>">Все категории</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('category',['category_id'=> $category->id])); ?>"
                       class="list-group-item <?php echo e(($category_id == $category->id) ? 'active' : ''); ?>"><?php echo e($category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

        <div class="col-md-9">

            <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <figure class="snip1423_category">
                        <img src="<?php echo e(($advert->image_latest) ? Storage::disk('public')->url($advert->image_latest->path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>" alt="sample57"/>
                        <figcaption>
                            <h3><?php echo e($advert->title); ?></h3>
                            <p><?php echo e(str_limit($advert->description,80)); ?></p>

                        </figcaption>
                        <i class="ion-information"></i>
                        <a href="<?php echo e(route('showAdvert', ['advert_id'=>$advert->id])); ?>"></a>
                    </figure>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$adverts->lastPage()): ?>
                <h3>В данном разделе пока нет объявлений</h3>
            <?php endif; ?>
        </div>
    </div>

    <div class="panel-footer">
        <div class="row">
            <?php echo $adverts->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>