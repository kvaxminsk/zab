<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="title m-b-md">
            <a href="<?php echo e(route('category',['category_id' => 0])); ?>">Вещи</a>
        </div>
        <?php $__currentLoopData = $adverts_first; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">

                <figure class="snip1423">
                    <img src="<?php echo e(($advert->image_latest) ? Storage::disk('public')->url($advert->image_latest->path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>" alt="sample57"/>
                    <figcaption>
                        <h3><?php echo e($advert->title); ?></h3>
                        <p><?php echo e(str_limit($advert->description,100)); ?></p>

                    </figcaption>
                    <i class="ion-information"></i>
                    <a href="<?php echo e(route('showAdvert', ['advert_id'=>$advert->id])); ?>"></a>
                </figure>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
        
            
        
        <?php $__currentLoopData = $adverts_second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">

                <figure class="snip1423">
                    <img src="<?php echo e(($advert->image_latest) ? Storage::disk('public')->url($advert->image_latest->path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>" alt="sample57"/>
                    <figcaption>
                        <h3><?php echo e($advert->title); ?></h3>
                        <p><?php echo e(str_limit($advert->description,100)); ?></p>

                    </figcaption>
                    <i class="ion-information"></i>
                    <a href="<?php echo e(route('showAdvert', ['advert_id'=>$advert->id])); ?>"></a>
                </figure>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
        
            
        
        <?php $__currentLoopData = $adverts_third; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">

                <figure class="snip1423">
                    <img src="<?php echo e(($advert->image_latest) ? Storage::disk('public')->url($advert->image_latest->path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>" alt="sample57"/>
                    <figcaption>
                        <h3><?php echo e($advert->title); ?></h3>
                        <p><?php echo e(str_limit($advert->description,100)); ?></p>

                    </figcaption>
                    <i class="ion-information"></i>
                    <a href="<?php echo e(route('showAdvert', ['advert_id'=>$advert->id])); ?>"></a>
                </figure>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>