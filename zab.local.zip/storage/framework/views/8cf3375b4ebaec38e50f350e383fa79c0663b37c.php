<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="item-container">
                <div class="container">
                    <div class="row" style="margin-top:20px">
                        <div class="col-md-12">
                            <div class="product col-md-5 service-image-left">
                                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                    <!-- Indicators -->
                                    <ol class="carousel-indicators">
                                        <?php $__currentLoopData = $advert->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li data-target="#myCarousel" data-slide-to="<?php echo e($image->id); ?>"
                                                class="active"></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>

                                    <!-- Wrapper for slides -->
                                    <div class="carousel-inner">
                                        <?php $i = 0;?>
                                        <?php $__currentLoopData = $advert->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item <?php echo e($i == 0 ? 'active' : ''); ?>">
                                                <img src="<?php echo e(Storage::disk('public')->url($image->path)); ?>"
                                                     alt="<?php echo e($advert->title); ?>_<?php echo e($image->advert_id); ?>">
                                            </div>
                                            <?php $i++?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                        
                                        

                                        
                                        
                                        
                                        
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="right carousel-control" href="#myCarousel" data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-md-7">
                                <div class="product-title"><?php echo e($advert->title); ?></div>
                                <div class="product-desc"><?php echo e(str_limit($advert->description)); ?>

                                </div>
                                <div class="product-rating"><i class="fa fa-star gold"></i> <i
                                            class="fa fa-star gold"></i>
                                    <i class="fa fa-star gold"></i> <i class="fa fa-star gold"></i> <i
                                            class="fa fa-star-o"></i></div>
                                <hr>
                                
                                <div class="product-stock">В наличии</div>
                                <hr>

                                <div class="btn-group wishlist">
                                    <a href="<?php echo e(route('userProfilePage', ['id'=>$advert->user_id])); ?>" class="btn btn-danger">
                                        Связаться с автором
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="col-md-12 product-info">
                        <ul id="myTab" class="nav nav-tabs nav_tabs">

                            <li class="active"><a href="#service-one" data-toggle="tab">DESCRIPTION</a></li>
                            
                            

                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div class="tab-pane fade in active" id="service-one">

                                <section class="container product-info">
                                    <p><?php echo e($advert->description); ?></p>
                                </section>

                            </div>
                            

                            

                            

                            
                            <div class="tab-pane fade" id="service-three">

                            </div>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.advert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>