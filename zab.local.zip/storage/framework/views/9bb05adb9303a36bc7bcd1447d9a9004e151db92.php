<?php $__env->startSection('seo_title'); ?>Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(array('route' => array('postUserEditProfile'),'method' => 'post','class'=>'form-horizontal','files' => true))); ?>

    <div class="jumbotron">
        <div class="row">
            <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4 center-block top">
            </div>
            <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4 center-block top">
                <img style="width:150px;height:150px;"
                     src="<?php echo e(($image_path) ? Storage::disk('public')->url($image_path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>"
                     alt="stack photo" class="img">
                <div class="text-center">
                    <?php echo e(Form::file('image',['class'=>'text-center center-block well well-sm','multiple'=>"multiple"])); ?>

                </div>
            </div>

        </div>
        <div class="row">
            <div class="panel-body">

                <?php echo e(Form::hidden('advert_id', $user->id)); ?>

                <div class="form-group">
                    <label class="col-lg-3 control-label">Имя:</label>
                    <div class="col-lg-8">
                        <?php echo e(Form::text('name',$user->name,array('class' => 'form-control'))); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Логин(будет отображаться везде):</label>
                    <div class="col-lg-8">
                        <?php echo e(Form::text('username',$user->username,array('class' => 'form-control'))); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Телефон</label>
                    <div class="col-lg-8">
                        <?php echo e(Form::text('phone',$user->phone,array('class' => 'form-control'))); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Страна</label>
                    <div class="col-lg-8">
                        <?php echo Form::select('country_id', $countries,$user->country_id,array('class' => 'form-control','id'=>'country_id',)); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Область</label>
                    <div class="col-lg-8">
                        <?php echo Form::select('region_id', $regions,$user->region_id,array('class' => 'form-control','id'=>'region_id')); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Город</label>
                    <div class="col-lg-8">
                        <?php echo Form::select('city_id', $cities,$user->city_id,array('class' => 'form-control','id'=>'city_id')); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label"></label>
                    <div class="col-md-8">
                        <?php echo e(Form::submit('Сохранить',array('class'=>'btn btn-primary'))); ?>

                    </div>

                </div>
                <?php echo e(Form::close()); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>