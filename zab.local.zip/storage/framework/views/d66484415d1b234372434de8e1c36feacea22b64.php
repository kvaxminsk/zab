<?php $__env->startSection('seo_title'); ?>Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="row">
            <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4 center-block top">

                <img style="width:150px;height:150px;"
                     src="<?php echo e(($user->image) ? Storage::disk('public')->url($user->image->path) : 'https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png'); ?>"
                     alt="stack photo" class="img">
            </div>
            <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                <div class="container" style="border-bottom:1px solid black">
                    <h2><?php echo e($user->name); ?></h2>
                </div>
                <hr>
                <ul class="container details">
                    
                    </p></li>
                    <?php if($user->country): ?>
                        <li><p style="font-size:14px"><span class="glyphicon glyphicon-map-marker one"
                                                            style="width:50px;"></span><?php echo e(($user->country) ? $user->country->title_ru :''); ?>

                                , <?php echo e(($user->region) ? $user->region->title_ru :''); ?>

                                , <?php echo e(($user->city) ? $user->city->title_ru :''); ?>

                            </p></li>
                    <?php endif; ?>
                    <li><p style="font-size:14px"><span class="glyphicon glyphicon-user one"
                                                        style="width:50px;"></span><?php echo e($user->email); ?>

                        </p></li>
                    <?php if($user->social_vk): ?>
                        <li><p style="font-size:14px"><a href="https://vk.com/id<?php echo e($user->social_vk->provider_user_id); ?>">VK</a>
                            </p>
                        </li>
                    <?php endif; ?>
                    <li><p style="font-size:14px"><span class="glyphicon glyphicon-user one"
                                                        style="width:50px;"></span><?php echo e($user->status->title); ?>

                        </p>
                </ul>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>