<div class="col-md-3">
    <div class="profile-sidebar">
        <!-- SIDEBAR USERPIC -->
        <div class="profile-userpic">
            <img src="http://keenthemes.com/preview/metronic/theme/assets/admin/pages/media/profile/profile_user.jpg"
                 class="img-responsive" alt="">
        </div>
        <!-- END SIDEBAR USERPIC -->
        <!-- SIDEBAR USER TITLE -->
        <div class="profile-usertitle">
            <div class="profile-usertitle-name">
                <?php echo e($user->name); ?>

            </div>
            
                
            
        </div>
        <!-- END SIDEBAR USER TITLE -->
        <!-- SIDEBAR BUTTONS -->
        
            
            
        
        <!-- END SIDEBAR BUTTONS -->
        <!-- SIDEBAR MENU -->
        <div class="profile-usermenu">
            <ul class="nav">
                <li <?php echo classActiveSegment(2, 'profile'); ?>>
                    <a href="<?php echo e(route('userProfilePage', ['id'=>$user->id])); ?>">
                        <i class="glyphicon glyphicon-home"></i>
                        Профиль </a>
                </li>
                <li <?php echo classActiveSegment(3, 'show_user_adverts'); ?>>
                    <a href="<?php echo e(route('showUserAdverts')); ?>">
                        <i class="glyphicon glyphicon-user"></i>
                        Объявления </a>
                </li >
                <?php if(Auth::user()->id == $user->id): ?>
                    <li <?php echo classActiveSegment(3, 'edit'); ?>>
                        <a href="<?php echo e(route('editUserProfilePage')); ?>">
                            <i class="glyphicon glyphicon-user"></i>
                            Редактировать профиль </a>
                    </li>
                    <li <?php echo classActiveSegment(2, 'cashout'); ?>>
                        <a href="<?php echo e(route('addAdvert')); ?>">
                            <i class="glyphicon glyphicon-user"></i>
                            Добавить объявление </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- END MENU -->
    </div>
</div>